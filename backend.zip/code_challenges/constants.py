MOUREDEV_URL = "https://moure.dev"
DISCORD_URL = "https://discord.gg/mouredev"
TWITCH_URL = "https://twitch.tv/mouredev"
YOUTUBE_URL = "https://youtube.com/@mouredev"
INSTAGRAM_URL = "https://instagram.com/mouredev"
TIKTOK_URL = "https://tiktok.com/@mouredev"

RAIOLA_NETWORKS_URL = "https://mouredev.link/raiola"

GITHUB_URL = "https://github.com/mouredev"
GITHUB_REPO_URL = "https://github.com/mouredev"
GITHUB_APPLIED_LOGIC_REPO_URL = "https://github.com/mouredev/logica-aplicada"
GITHUB_ROADMAP_REPO_URL = "https://github.com/mouredev/roadmap-retos-programacion"
GITHUB_EXERCISES_REPO_URL = "https://github.com/mouredev/retos-programacion-2023"
GITHUB_PROJECTS_REPO_URL = "https://github.com/mouredev/Monthly-App-Challenge-2022"
GITHUB_WEB_REPO_URL = "https://github.com/mouredev/retos-programacion-web"

GOOGLE_ANALYTICS_TAG = "G-TWVM4FPR6X"
